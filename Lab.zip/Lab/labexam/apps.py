from django.apps import AppConfig


class LabexamConfig(AppConfig):
    name = 'labexam'
